function Home() {
    return (
        <div className="home">
            <h2>Bem vindo ao Adote um amigo!</h2>
            <p>Veja um video sobre adoção responsavel: </p>
            <iframe 
            src="https://www.youtube.com/watch?v=J6MCq2IcKPQ&pp=ygUgYWRvw6fDo28gcmVzcG9uc8OhdmVsIGRlIGFuaW1haXM%3D  " 
            frameborder="0" 
            width={560} 
            height={315}
            title="Adoção Responsavel"
            allowFullScreen
            ></iframe>
        </div>
    )
}

export default Home