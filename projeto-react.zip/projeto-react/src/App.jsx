import './App.css'
import Header from './componentes/header'
import Home from './pages/home'
import Animais from './pages/animais'
import { useState } from 'react'


function App() {
  const[pagina, setpagina] = useState("home")

  return (
    <>
    <Header/>

    <nav>
      <button className="botao-inicio" onClick={() => setpagina("home")}>Inicio</button>

      <button className="botao-animais" onClick={() => setpagina("animais")}>Ver Animais</button> 
    </nav>

    {pagina == "home" && <Home/>}
    {pagina == "animais" && <Animais/>}
    </>
  )
}

export default App
