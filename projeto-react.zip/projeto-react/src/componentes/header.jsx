function Header() {
    return (
        <header>
             <h1>🐶 Adote um Amigo 🐱</h1>
        </header>
    )
}

export default Header